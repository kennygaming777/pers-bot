const discord = require("discord.js");

module.exports = {
  name: "invite",
  category: "info",
  description: "INVITE W.A.Y",
  run: async (client, message, args) => {
    
    let embed = new discord.MessageEmbed()
    .setTitle(`https://discord.com/api/oauth2/authorize?client_id=891005233008889887&permissions=536870911991&scope=bot`)
    .setDescription(`<:link:845315257430048788>  [CLICK HERE](https://discord.com/api/oauth2/authorize?client_id=839010097585324062&permissions=8&scope=bot) OR [support server ](https://discord.gg/DMwYAEDXts)`)
    .setColor("RANDOM")
    .setFooter(`made by Kenny `)
    .setTimestamp(message.timestamp = Date.now())
    
    message.channel .send(embed)
    
  
  }
}